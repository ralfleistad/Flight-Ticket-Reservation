/**
 * TITLE: RegisterActivity.java
 * ABSTRACT: This is the activity for registering a new account.
 * AUTHOR: Ralf Leistad
 * DATE: 12/14/2018
 */

package com.example.ralfleistad.airline_ticket_reservation;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegisterActivity extends AppCompatActivity {

    public static final String TAG = "USER-REGISTER";

    Button btnConfirm;
    Button btnCancel;
    EditText editTextUsername;
    EditText editTextPassword;

    User user;
    UserDB userDB;

    Logs log;
    LogDB logDB;


    int attempts = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        btnConfirm = findViewById(R.id.btnConfirm);
        btnCancel = findViewById(R.id.btnCancel);
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);

        btnConfirm.setOnClickListener(buttonListener);
        btnCancel.setOnClickListener(buttonListener);

        userDB = UserDB.get(this.getApplicationContext());
        logDB = LogDB.get(this.getApplicationContext());


    }

    // BUTTON LISTENER
    private View.OnClickListener buttonListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            switch (v.getId()) {
                case R.id.btnConfirm:


                    if(!validateInformation()) {
                        attempts++;
                        failedAttempt("Invalid Format", "Your password / username does not meet the requirements").show();
                        log = getLogItem(false);
                        logDB.addLog(log);
                    } else {

                        String username = editTextUsername.getText().toString();

                        if(userDB.existingUser(username)) {
                            attempts++;
                            failedAttempt("Username Unavailable", "That username is already in use").show();
                            log = getLogItem(false);
                            logDB.addLog(log);
                        } else {
                            user = getUserFromDisplay();
                            userDB.addUser(user);

                            log = getLogItem(true);
                            logDB.addLog(log);

                            AlertDialog alert = createDialog();
                            alert.show();
                        }
                    }
                    break;

                case R.id.btnCancel:
                    finish();
                    break;
            }
        }
    };


    // VALIDATE INFORMATION
    public boolean validateInformation() {

        String username = editTextUsername.getText().toString();
        String password = editTextPassword.getText().toString();

        String REGEX_PATTERN = "(?=.*[a-zA-Z].*[a-zA-Z].*[a-zA-Z].*)(?=.*\\d.*)[a-zA-Z0-9]{4,}";

        Pattern pattern = Pattern.compile(REGEX_PATTERN);
        Matcher matcherName = pattern.matcher(username);
        Matcher matcherPass = pattern.matcher(password);

        if(!matcherName.matches()) {
            return false;
        } else if (!matcherPass.matches()) {
            return false;
        } else {
            return true;
        }
    }


    public User getUserFromDisplay() {

        User tempUser = new User();

        String username = editTextUsername.getText().toString();
        String password = editTextPassword.getText().toString();

        tempUser.setUsername(username);
        tempUser.setPassword(password);

        return tempUser;
    }


    public Logs getLogItem(boolean successfulCreated) {
        Logs tempLog = new Logs();

        String username = editTextUsername.getText().toString();

        if(successfulCreated) {

            String message = "New Account";

            tempLog.setMessage(message);
            tempLog.setUsername(username);
        } else {
            if(!username.isEmpty()) {
                tempLog.setUsername(username);
            } else {
                tempLog.setUsername("null");
            }
            tempLog.setMessage("Account Creation Failed");
        }


        return tempLog;
    }


    public Dialog failedAttempt(String reason, String message) {
        AlertDialog.Builder alert = new AlertDialog.Builder(RegisterActivity.this, R.style.MyDialogTheme);

        alert.setTitle(reason).setCancelable(false);

        alert.setMessage(message + "\n\nAttempts Left: " + (2-attempts));

        if(attempts < 2) {
            alert.setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
        }

        alert.setNegativeButton("Exit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(RegisterActivity.this, MainActivity.class));
            }
        });

        return alert.create();
    }


    public AlertDialog createDialog() {
        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(RegisterActivity.this, R.style.MyDialogTheme);

        alertBuilder.setTitle("ACCOUNT CREATED")
                .setCancelable(false)
                .setMessage("Your account was successfully created!\nThanks for using Otter Airlines!")
                .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });

        return alertBuilder.create();
    }


}
