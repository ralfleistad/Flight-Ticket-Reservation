/**
 * TITLE: UserDB.java
 * ABSTRACT: This is the file that indirectly manipulates the user table in the database.
 * AUTHOR: Ralf Leistad
 * DATE: 12/14/2018
 */

package com.example.ralfleistad.airline_ticket_reservation;

import android.content.Context;

import com.example.ralfleistad.airline_ticket_reservation.Databse.DBHelper;

public class UserDB {

    private static UserDB sUserDB;
    private Context mContext;
    private DBHelper mDBHelper;


    public static UserDB get(Context context) {
        if(sUserDB == null){
            sUserDB = new UserDB(context);
        }
        return sUserDB;
    }

    private UserDB(Context context) {
        mContext = context.getApplicationContext();
        mDBHelper = new DBHelper(mContext);
    }

    public long addUser(User user) {
        return mDBHelper.addUser(user);
    }

    public boolean existingUser(String name) {
        return mDBHelper.duplicateName(name);
    }

    public boolean checkLogin(String name, String pass) {
        return mDBHelper.login(name, pass);
    }
}
