/**
 * TITLE: Reservation.java
 * ABSTRACT: This is the class for defining a reservation. It includes getters, setters, toString and constructors.
 * AUTHOR: Ralf Leistad
 * DATE: 12/14/2018
 */

package com.example.ralfleistad.airline_ticket_reservation;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

public class Reservation {

    private UUID reservationId;
    private String departure;
    private String arrival;
    private String username;
    private String flightnumber;

    private static List<Integer> AllReservationNumber = new ArrayList<>();

    private double price;

    private int tickets;
    private int sqlReservationId;
    private int reservationNumber;

    public Reservation() {
        reservationId = UUID.randomUUID();
    }

    public Reservation(UUID id) {
        reservationId = id;
    }


    public static int randomNumber() {
        Random rand = new Random();
        int temp = rand.nextInt((1000 - 1) + 1) + 1;

        while (getAllReservationNumber().contains(temp)) {
            randomNumber();
        }

        getAllReservationNumber().add(temp);
        return temp;
    }


    public static List<Integer> getAllReservationNumber() {
        return AllReservationNumber;
    }

    public int getReservationNumber() {
        return reservationNumber;
    }

    public void setReservationNumber(int reservationNumber) {
        this.reservationNumber = reservationNumber;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getTickets() {
        return tickets;
    }

    public void setTickets(int tickets) {
        this.tickets = tickets;
    }

    public UUID getReservationId() {
        return reservationId;
    }

    public void setReservationId(UUID reservationId) {
        this.reservationId = reservationId;
    }

    public String getDeparture() {
        return departure;
    }

    public void setDeparture(String departure) {
        this.departure = departure;
    }

    public String getArrival() {
        return arrival;
    }

    public void setArrival(String arrival) {
        this.arrival = arrival;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getSqlReservationId() {
        return sqlReservationId;
    }

    public void setSqlReservationId(int sqlReservationId) {
        this.sqlReservationId = sqlReservationId;
    }

    public String getFlightnumber() {
        return flightnumber;
    }

    public void setFlightnumber(String flightnumber) {
        this.flightnumber = flightnumber;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("Reservation Number: ???\n");

        return sb.toString();
    }
}
