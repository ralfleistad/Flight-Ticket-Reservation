/**
 * TITLE: DBCursorWrapper.java
 * ABSTRACT: This is the CursorWrapper class.
 * AUTHOR: Ralf Leistad
 * DATE: 12/14/2018
 */


package com.example.ralfleistad.airline_ticket_reservation.Databse;

import android.database.Cursor;

import com.example.ralfleistad.airline_ticket_reservation.Flight;
import com.example.ralfleistad.airline_ticket_reservation.Logs;
import com.example.ralfleistad.airline_ticket_reservation.Reservation;
import com.example.ralfleistad.airline_ticket_reservation.User;

import java.util.Date;
import java.util.UUID;

public class DBCursorWrapper extends android.database.CursorWrapper {

    public DBCursorWrapper(Cursor cursor) {
        super(cursor);
    }

    public User getUser() {
        String uuidString = getString(getColumnIndex(Schemas.UsersTable.Cols.UUID));
        String username = getString(getColumnIndex(Schemas.UsersTable.Cols.USERNAME));
        String password = getString(getColumnIndex(Schemas.UsersTable.Cols.PASSWORD));

        int sqlUserId = getInt(getColumnIndex("_id"));


        User user = new User(UUID.fromString(uuidString));

        user.setUsername(username);
        user.setPassword(password);
        user.setSqlUserId(sqlUserId);

        return user;
    }

    public Logs getLogs() {
        String uuidString = getString(getColumnIndex(Schemas.LogsTable.Cols.UUID));
        String username = getString(getColumnIndex(Schemas.LogsTable.Cols.USERNAME));
        String message = getString(getColumnIndex(Schemas.LogsTable.Cols.MESSAGE));

        int sqlLogId = getInt(getColumnIndex("_id"));

        Date date = new Date(getLong(getColumnIndex(Schemas.LogsTable.Cols.DATE)));

        Logs logs = new Logs(UUID.fromString(uuidString));

        logs.setSqlLogId(sqlLogId);
        logs.setMessage(message);
        logs.setUsername(username);
        logs.setDate(date);

        return logs;
    }

    public Flight getFlight() {
        String uuidString = getString(getColumnIndex(Schemas.FlightsTable.Cols.UUID));
        String flightNumber = getString(getColumnIndex(Schemas.FlightsTable.Cols.FLIGHTNUMBER));
        String departure = getString(getColumnIndex(Schemas.FlightsTable.Cols.DEPARTURE));
        String arrival = getString(getColumnIndex(Schemas.FlightsTable.Cols.ARRIVAL));
        String time = getString(getColumnIndex(Schemas.FlightsTable.Cols.TIME));

        int tickets = getInt(getColumnIndex(Schemas.FlightsTable.Cols.TICKETS));
        int sqlFlightId = getInt(getColumnIndex("_id"));

        double price = getDouble(getColumnIndex(Schemas.FlightsTable.Cols.PRICE));

        Flight flight = new Flight(UUID.fromString(uuidString));

        flight.setArrival(arrival);
        flight.setTickets(tickets);
        flight.setDeparture(departure);
        flight.setTime(time);
        flight.setFlightNumber(flightNumber);
        flight.setPrice(price);
        flight.setSqlFlightId(sqlFlightId);

        return flight;
    }

    public Reservation getReservation() {
        String uuidString = getString(getColumnIndex(Schemas.ReservationsTable.Cols.UUID));
        String departure = getString(getColumnIndex(Schemas.ReservationsTable.Cols.DEPARTURE));
        String arrival = getString(getColumnIndex(Schemas.ReservationsTable.Cols.ARRIVAL));
        String username = getString(getColumnIndex(Schemas.ReservationsTable.Cols.USERNAME));
        String flightnumber = getString(getColumnIndex(Schemas.ReservationsTable.Cols.FLIGHTNUMBER));

        int tickets = getInt(getColumnIndex(Schemas.ReservationsTable.Cols.TICKETS));
        int sqlReservationId = getInt(getColumnIndex("_id"));
        int reservationNum = getInt(getColumnIndex(Schemas.ReservationsTable.Cols.RESERVATIONNUMBER));

        double price = getDouble(getColumnIndex(Schemas.ReservationsTable.Cols.PRICE));

        Reservation reservation = new Reservation(UUID.fromString(uuidString));

        reservation.setDeparture(departure);
        reservation.setArrival(arrival);
        reservation.setPrice(price);
        reservation.setTickets(tickets);
        reservation.setUsername(username);
        reservation.setFlightnumber(flightnumber);
        reservation.setSqlReservationId(sqlReservationId);
        reservation.setReservationNumber(reservationNum);

        return reservation;
    }
}
