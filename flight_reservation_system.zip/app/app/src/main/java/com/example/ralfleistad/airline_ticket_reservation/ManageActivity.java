/**
 * TITLE: ManageActivity.java
 * ABSTRACT: This is the activity for the system operator log-in.
 * AUTHOR: Ralf Leistad
 * DATE: 12/14/2018
 */

package com.example.ralfleistad.airline_ticket_reservation;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ManageActivity extends AppCompatActivity {

    Button btnConfirm;
    Button btnCancel;
    EditText editTextUsername;
    EditText editTextPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage);

        btnConfirm = findViewById(R.id.btnConfirm);
        btnCancel = findViewById(R.id.btnCancel);
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);

        btnConfirm.setOnClickListener(buttonListener);
        btnCancel.setOnClickListener(buttonListener);

    }

    private View.OnClickListener buttonListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            switch (v.getId()) {
                case R.id.btnConfirm:

                    if(validateInformation()) {
                        startActivity(new Intent(ManageActivity.this, AddFlightActivity.class));
                    } else {
                        Dialog alert = createDialog();
                        alert.show();
                    }
                    break;

                case R.id.btnCancel:
                    finish();
                    break;
            }
        }
    };


    public Dialog createDialog() {
        final AlertDialog.Builder alertBuilder = new AlertDialog.Builder(ManageActivity.this, R.style.MyDialogTheme);

        alertBuilder.setTitle("SYSTEM LOGIN FAILED")
                .setCancelable(false)
                .setMessage("Only the system operator are allowed to log in here!")
                .setNegativeButton("Confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        Dialog dialog = alertBuilder.create();
        return dialog;
    }

    public boolean validateInformation() {
        String username = editTextUsername.getText().toString();
        String password = editTextPassword.getText().toString();

        return (username.equals("admin2") && password.equals("admin2"));
    }
}
