/**
 * TITLE: ReservationDB.java
 * ABSTRACT: This is the file for indirectly manipulating the reservation table in the database.
 * AUTHOR: Ralf Leistad
 * DATE: 12/14/2018
 */

package com.example.ralfleistad.airline_ticket_reservation;

import android.content.Context;

import com.example.ralfleistad.airline_ticket_reservation.Databse.DBHelper;

import java.util.List;
import java.util.UUID;

public class ReservationDB {

    private static ReservationDB sReservationDB;
    private Context mContext;
    private DBHelper mDBHelper;


    public static ReservationDB get(Context context) {
        if(sReservationDB == null){
            sReservationDB = new ReservationDB(context);
        }
        return sReservationDB;
    }

    private ReservationDB(Context context) {
        mContext = context.getApplicationContext();
        mDBHelper = new DBHelper(mContext);
    }

    public long addReservation(Reservation reservation) {
        return mDBHelper.addReservation(reservation);
    }

    public List<Reservation> getReservationList() {
        return mDBHelper.getReservationList();
    }

    public List<Reservation> getUsersReservations(String name) {
        return mDBHelper.userReservations(name);
    }

    public void cancelReservation(Reservation reservation) {
        mDBHelper.addReservation(reservation);
    }

    public int removeReservation(UUID target) {
        return mDBHelper.delete(target);
    }

}
