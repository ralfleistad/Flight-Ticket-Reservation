/**
 * TITLE: DBHelper.java
 * ABSTRACT: This is the file to directly handle all database manipulation.
 * AUTHOR: Ralf Leistad
 * DATE: 12/14/2018
 */

package com.example.ralfleistad.airline_ticket_reservation.Databse;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.ralfleistad.airline_ticket_reservation.Databse.Schemas.UsersTable;
import com.example.ralfleistad.airline_ticket_reservation.Databse.Schemas.LogsTable;
import com.example.ralfleistad.airline_ticket_reservation.Databse.Schemas.FlightsTable;
import com.example.ralfleistad.airline_ticket_reservation.Databse.Schemas.ReservationsTable;
import com.example.ralfleistad.airline_ticket_reservation.Flight;
import com.example.ralfleistad.airline_ticket_reservation.User;
import com.example.ralfleistad.airline_ticket_reservation.Logs;
import com.example.ralfleistad.airline_ticket_reservation.Reservation;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class DBHelper extends SQLiteOpenHelper {

    private static final String TAG = "AIRLINE-DB";

    private static final int VERSION            = 1;
    public static final String DATABASE_NAME    = "airlinesystem.db";

    private SQLiteDatabase db;


    public DBHelper(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        // CREATE USERS TABLE
        db.execSQL("create table " + UsersTable.NAME + "(" +
                " _id integer primary key autoincrement, " +
                UsersTable.Cols.USERNAME + ","+
                UsersTable.Cols.PASSWORD + ","+
                UsersTable.Cols.UUID +
                ")"
        );

        // CREATE LOGS TABLE
        db.execSQL("create table " + LogsTable.NAME + "(" +
                " _id integer primary key autoincrement, " +
                LogsTable.Cols.UUID + "," +
                LogsTable.Cols.USERNAME + "," +
                LogsTable.Cols.DATE + "," +
                LogsTable.Cols.MESSAGE +
                ")"
        );

        // CREATE FLIGHTS TABLE
        db.execSQL("create table " + FlightsTable.NAME + "(" +
                " _id integer primary key autoincrement, " +
                FlightsTable.Cols.UUID + "," +
                FlightsTable.Cols.FLIGHTNUMBER + "," +
                FlightsTable.Cols.DEPARTURE + "," +
                FlightsTable.Cols.ARRIVAL + "," +
                FlightsTable.Cols.TICKETS + "," +
                FlightsTable.Cols.TIME + "," +
                FlightsTable.Cols.PRICE +
                ")"
        );

        // CREATE RESERVATIONS TABLE
        db.execSQL("create table " + ReservationsTable.NAME + "(" +
                " _id integer primary key autoincrement, " +
                ReservationsTable.Cols.UUID + "," +
                ReservationsTable.Cols.DEPARTURE + "," +
                ReservationsTable.Cols.ARRIVAL + "," +
                ReservationsTable.Cols.USERNAME + "," +
                ReservationsTable.Cols.TICKETS + "," +
                ReservationsTable.Cols.PRICE + "," +
                ReservationsTable.Cols.FLIGHTNUMBER + "," +
                ReservationsTable.Cols.RESERVATIONNUMBER +
                ")"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


    private Cursor queryDB(String DBName, String whereClause, String[] whereArgs){
        db = this.getWritableDatabase();

        try{
            return db.query(DBName,
                    null,
                    whereClause,
                    whereArgs,
                    null,
                    null,
                    null);
        }catch (Exception e){
            Log.d(TAG, "Problem in queryDB!!");
            return null;
        }
    }


    /*********************
     *                   *
     *   USER HANDLING   *
     *                   *
     *********************/

    private long insertUser(User user) {
        ContentValues cv = getContentValuesUser(user);

        db = this.getWritableDatabase();

        return db.insert(UsersTable.NAME, null, cv);
    }


    public long addUser(User user) {
        if(this.getUser(user.getUserId()) == null) {
            return insertUser(user);
        } else {
            return updateUser(user);
        }
    }


    private int updateUser(User user) {
        db = this.getWritableDatabase();
        ContentValues cv = DBHelper.getContentValuesUser(user);
        String whereClause = UsersTable.Cols.UUID + " = ? ";
        String[] whereArgs = {user.getUserId().toString()};
        try{
            return db.update(UsersTable.NAME, cv, whereClause, whereArgs);
        } catch (Exception e){
            Log.d(TAG, "something is wrong in updateUser");
            return -1;
        }
    }


    public boolean duplicateName(String username) {

        List<User> users = getUsersList();

        if(users == null) {
            return false;
        }

        for(User user : users) {
            if(user.getUsername().equals(username)) {
                return true;
            }
        }

        return false;
    }


    private List<User> getUsersList() {
        List<User> logs = new ArrayList<>();

        DBCursorWrapper cursor = new DBCursorWrapper(this.queryDB(UsersTable.NAME,null,null));
        try{
            if(cursor.getCount() == 0){
                Log.d(TAG, "getUserList returned nothing...");
                return null;
            }
            cursor.moveToFirst();
            while(!cursor.isAfterLast()){
                logs.add(cursor.getUser());
                cursor.moveToNext();
            }
        }finally {

            cursor.close();
        }

        return logs;
    }


    private User getUser(UUID userUUID) {
        String whereClause = UsersTable.Cols.UUID + " = ? ";
        String[] whereArgs = {userUUID.toString()};

        DBCursorWrapper cursor = new DBCursorWrapper(this.queryDB(UsersTable.NAME,whereClause,whereArgs));

        try {
            if (cursor.getCount() == 0){
                Log.d(TAG, "No results from getUser");
                return null;
            }
            cursor.moveToFirst();
            return cursor.getUser();
        } finally {
            cursor.close();
        }
    }


    private static ContentValues getContentValuesUser(User user){
        ContentValues cv = new ContentValues();
        cv.put(UsersTable.Cols.USERNAME, user.getUsername());
        cv.put(UsersTable.Cols.PASSWORD, user.getPassword());
        cv.put(UsersTable.Cols.UUID, user.getUserId().toString());

        return cv;
    }


    public boolean login(String name, String pass) {
        List<User> users = getUsersList();

        if(users != null) {
            for (User user : users) {
                if (user.getUsername().equals(name)) {
                    if (user.getPassword().equals(pass)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }


    /********************
     *                  *
     *   LOG HANDLING   *
     *                  *
     ********************/

    private long insertLog(Logs log) {
        ContentValues cv = getContentValuesLog(log);

        db = this.getWritableDatabase();

        return db.insert(Schemas.LogsTable.NAME, null, cv);
    }


    public long addLog(Logs log) {
        if(this.getLog(log.getLogId()) == null) {
            return insertLog(log);
        } else {
            return updateLog(log);
        }
    }


    private int updateLog(Logs log) {
        db = this.getWritableDatabase();

        ContentValues cv = DBHelper.getContentValuesLog(log);
        String whereClause = LogsTable.Cols.UUID + " = ? ";
        String[] whereArgs = {log.getLogId().toString()};

        try{
            return db.update(LogsTable.NAME, cv, whereClause, whereArgs);
        } catch (Exception e){
            Log.d(TAG, "something is wrong in updateLog");
            return -1;
        }
    }


    public List<Logs> getLogsList() {
        List<Logs> logs = new ArrayList<>();

        DBCursorWrapper cursor = new DBCursorWrapper(this.queryDB(LogsTable.NAME,null,null));
        try{
            if(cursor.getCount() == 0){
                Log.d(TAG, "getLogsList returned nothing...");
                return null;
            }
            cursor.moveToFirst();
            while(!cursor.isAfterLast()){
                logs.add(cursor.getLogs());
                cursor.moveToNext();
            }
        }finally {

            cursor.close();
        }

        return logs;
    }


    private Logs getLog(UUID logsUUID) {
        String whereClause = LogsTable.Cols.UUID + " = ? ";
        String[] whereArgs = {logsUUID.toString()};

        DBCursorWrapper cursor = new DBCursorWrapper(this.queryDB(LogsTable.NAME,whereClause,whereArgs));

        try {
            if (cursor.getCount() == 0){
                Log.d(TAG, "No results from getUser");
                return null;
            }
            cursor.moveToFirst();
            return cursor.getLogs();
        } finally {
            cursor.close();
        }
    }


    public static ContentValues getContentValuesLog(Logs log){
        ContentValues cv = new ContentValues();

        cv.put(LogsTable.Cols.UUID, log.getLogId().toString());
        cv.put(LogsTable.Cols.DATE, log.getDate().getTime());
        cv.put(LogsTable.Cols.MESSAGE, log.getMessage());
        cv.put(LogsTable.Cols.USERNAME, log.getUsername());

        return cv;
    }


    /***********************
     *                     *
     *   FLIGHT HANDLING   *
     *                     *
     ***********************/

    private long insertFlight(Flight flight) {
        ContentValues cv = getContentValuesFlight(flight);

        db = this.getWritableDatabase();

        return db.insert(Schemas.FlightsTable.NAME, null, cv);
    }


    public long addFlight(Flight flight) {
        if(this.getFlight(flight.getFlightId()) == null) {
            return insertFlight(flight);
        } else {
            return updateFlight(flight);
        }
    }


    private int updateFlight(Flight flight) {
        db = this.getWritableDatabase();

        ContentValues cv = DBHelper.getContentValuesFlight(flight);
        String whereClause = FlightsTable.Cols.UUID + " = ? ";
        String[] whereArgs = {flight.getFlightId().toString()};

        try{
            return db.update(FlightsTable.NAME, cv, whereClause, whereArgs);
        } catch (Exception e){
            Log.d(TAG, "something is wrong in updateFlight");
            return -1;
        }
    }



    public List<Flight> getFlightList() {
        List<Flight> flights = new ArrayList<>();

        DBCursorWrapper cursor = new DBCursorWrapper(this.queryDB(FlightsTable.NAME,null,null));
        try{
            if(cursor.getCount() == 0){
                Log.d(TAG, "getFlightList returned nothing...");
                return null;
            }
            cursor.moveToFirst();
            while(!cursor.isAfterLast()){
                flights.add(cursor.getFlight());
                Log.d(TAG, "flight added to list");
                cursor.moveToNext();
            }
        }finally {

            cursor.close();
        }

        return flights;
    }


    public List<Flight> getAllAvailable(String from, String to, int quantity) {
        List<Flight> allFlights = getFlightList();
        List<Flight> flights = new ArrayList<>();

        if(allFlights == null) {
            return null;
        }

        for(Flight flight : allFlights) {
            if(flight.getDeparture().equals(from)) {
                if(flight.getArrival().equals(to)) {
                    if(flight.getTickets() >= quantity) {
                        flights.add(flight);
                    }
                }
            }
        }

        return flights;
    }


    public Flight getFlightFromFlightnumber(String num) {
        List<Flight> flights = getFlightList();

        if(flights != null) {
            for (Flight flight : flights) {
                if (flight.getFlightNumber().equals(num)) {
                    return flight;
                }
            }
        }

        return null;
    }


    private Flight getFlight(UUID flightUUID) {
        String whereClause = FlightsTable.Cols.UUID + " = ? ";
        String[] whereArgs = {flightUUID.toString()};

        DBCursorWrapper cursor = new DBCursorWrapper(this.queryDB(FlightsTable.NAME,whereClause,whereArgs));

        try {
            if (cursor.getCount() == 0){
                Log.d(TAG, "No results from getFlight");
                return null;
            }
            cursor.moveToFirst();
            return cursor.getFlight();
        } finally {
            cursor.close();
        }
    }


    public static ContentValues getContentValuesFlight(Flight flight){
        ContentValues cv = new ContentValues();

        cv.put(FlightsTable.Cols.UUID, flight.getFlightId().toString());
        cv.put(FlightsTable.Cols.ARRIVAL, flight.getArrival());
        cv.put(FlightsTable.Cols.DEPARTURE, flight.getDeparture());
        cv.put(FlightsTable.Cols.FLIGHTNUMBER, flight.getFlightNumber());
        cv.put(FlightsTable.Cols.TIME, flight.getTime());
        cv.put(FlightsTable.Cols.PRICE, flight.getPrice());
        cv.put(FlightsTable.Cols.TICKETS, flight.getTickets());

        return cv;
    }



    /****************************
     *                          *
     *   RESERVATION HANDLING   *
     *                          *
     ****************************/

    private long insertReservation(Reservation reservation) {
        ContentValues cv = getContentValuesReservation(reservation);

        db = this.getWritableDatabase();

        return db.insert(Schemas.ReservationsTable.NAME, null, cv);
    }


    public long addReservation(Reservation reservation) {
        if(this.getReservation(reservation.getReservationId()) == null) {
            return insertReservation(reservation);
        } else {
            return updateReservation(reservation);
        }
    }


    private int updateReservation(Reservation reservation) {
        db = this.getWritableDatabase();

        ContentValues cv = DBHelper.getContentValuesReservation(reservation);
        String whereClause = ReservationsTable.Cols.UUID + " = ? ";
        String[] whereArgs = {reservation.getReservationId().toString()};

        try{
            return db.update(ReservationsTable.NAME, cv, whereClause, whereArgs);
        } catch (Exception e){
            Log.d(TAG, "something is wrong in updateReservation");
            return -1;
        }
    }


    public List<Reservation> getReservationList() {
        List<Reservation> reservations = new ArrayList<>();

        DBCursorWrapper cursor = new DBCursorWrapper(this.queryDB(ReservationsTable.NAME,null,null));
        try{
            if(cursor.getCount() == 0){
                Log.d(TAG, "getReservationList returned nothing...");
                return null;
            }
            cursor.moveToFirst();
            while(!cursor.isAfterLast()){
                reservations.add(cursor.getReservation());
                Log.d(TAG, "reservation added to list");
                cursor.moveToNext();
            }
        }finally {

            cursor.close();
        }

        return reservations;
    }


    public List<Reservation> userReservations(String name) {
        List<Reservation> allReservations = getReservationList();
        List<Reservation> userReserve = new ArrayList<>();

        if(allReservations == null) {
            return null;
        }

        for(Reservation res : allReservations) {
            if(res.getUsername().equals(name)) {
                userReserve.add(res);
            }
        }

        return userReserve;
    }


    public int delete(UUID removeThis) {
        db = this.getWritableDatabase();

        return db.delete(ReservationsTable.NAME, UsersTable.Cols.UUID + " = ? ", new String[]{removeThis.toString()});
    }


    public Reservation getReservation(UUID reservationUUID) {
        String whereClause = ReservationsTable.Cols.UUID + " = ? ";
        String[] whereArgs = {reservationUUID.toString()};

        DBCursorWrapper cursor = new DBCursorWrapper(this.queryDB(ReservationsTable.NAME,whereClause,whereArgs));

        try {
            if (cursor.getCount() == 0){
                Log.d(TAG, "No results from getFlight");
                return null;
            }
            cursor.moveToFirst();
            return cursor.getReservation();
        } finally {
            cursor.close();
        }
    }


    public static ContentValues getContentValuesReservation(Reservation reservation){
        ContentValues cv = new ContentValues();

        cv.put(ReservationsTable.Cols.UUID, reservation.getReservationId().toString());
        cv.put(ReservationsTable.Cols.DEPARTURE, reservation.getDeparture());
        cv.put(ReservationsTable.Cols.ARRIVAL, reservation.getArrival());
        cv.put(ReservationsTable.Cols.TICKETS, reservation.getTickets());
        cv.put(ReservationsTable.Cols.PRICE, reservation.getPrice());
        cv.put(ReservationsTable.Cols.USERNAME, reservation.getUsername());
        cv.put(ReservationsTable.Cols.FLIGHTNUMBER, reservation.getFlightnumber());
        cv.put(ReservationsTable.Cols.RESERVATIONNUMBER, reservation.getReservationNumber());

        return cv;
    }

}
