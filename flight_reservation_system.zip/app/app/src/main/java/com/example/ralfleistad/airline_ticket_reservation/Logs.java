/**
 * TITLE: Logs.java
 * ABSTRACT: This is the file for defining and creating a log-object.
 * AUTHOR: Ralf Leistad
 * DATE: 12/14/2018
 */

package com.example.ralfleistad.airline_ticket_reservation;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

public class Logs {

    private UUID logId;
    private String username;
    private String message;
    private int sqlLogId;

    private SimpleDateFormat ftDate = new SimpleDateFormat("dd-M-yyyy");
    private Date date;

    private SimpleDateFormat ftTime = new SimpleDateFormat("HH:mm");

    public Logs(){
        logId = UUID.randomUUID();
        date = new Date();
    }

    public Logs(UUID id){
        logId = id;
    }

    public SimpleDateFormat getDateFormat() {
        return ftDate;
    }

    public String getDateString(){
        return ftDate.format(date);
    }

    public String getTimeString() {
        return ftTime.format(date);
    }

    public UUID getLogId() {
        return logId;
    }

    public void setLogId(UUID logId) {
        this.logId = logId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getSqlLogId() {
        return sqlLogId;
    }

    public void setSqlLogId(int sqlLogId) {
        this.sqlLogId = sqlLogId;
    }

    public void setDateFormat(SimpleDateFormat ft) {
        this.ftDate = ft;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public SimpleDateFormat getFtDate() {
        return ftDate;
    }

    public void setFtDate(SimpleDateFormat ftDate) {
        this.ftDate = ftDate;
    }

    public SimpleDateFormat getFtTime() {
        return ftTime;
    }

    public void setFtTime(SimpleDateFormat ftTime) {
        this.ftTime = ftTime;
    }


    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("Log Entry #").append(getSqlLogId()).append("\n");
        sb.append("Customers Username: ").append(getUsername()).append("\n");
        sb.append("Transaction: ").append(message).append("\n");
        sb.append("Transaction Date: ").append(getDateString()).append("\n");
        sb.append("Transaction Time: ").append(getTimeString()).append("\n\n");

        return sb.toString();
    }
}
