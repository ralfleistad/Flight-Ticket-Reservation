/**
 * TITLE: ReserveActivity.java
 * ABSTRACT: This is the activity for reserving one or more seats on a flight.
 * AUTHOR: Ralf Leistad
 * DATE: 12/14/2018
 */

package com.example.ralfleistad.airline_ticket_reservation;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ReserveActivity extends AppCompatActivity {

    EditText editTextDepart;
    EditText editTextArrive;
    EditText editTextTickets;
    Button btnConfirm;
    Button btnCancel;

    User user;
    UserDB userDB;

    Flight flight;
    FlightDB flightDB;

    Reservation reservation;
    ReservationDB reservationDB;

    Logs log;
    LogDB logDB;

    String USERNAME;
    int SEATS;
    double CASH;

    int reservationNum = Reservation.randomNumber();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserve);

        editTextDepart = findViewById(R.id.editTextDepart);
        editTextArrive = findViewById(R.id.editTextArrive);
        editTextTickets = findViewById(R.id.editTextTickets);
        btnConfirm = findViewById(R.id.btnConfirm);
        btnCancel = findViewById(R.id.btnCancel);

        btnConfirm.setOnClickListener(buttonListener);
        btnCancel.setOnClickListener(buttonListener);

        flightDB = FlightDB.get(this.getApplicationContext());
        userDB = UserDB.get(this.getApplicationContext());
        reservationDB = ReservationDB.get(this.getApplicationContext());
        logDB = LogDB.get(this.getApplicationContext());
    }

    private View.OnClickListener buttonListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            switch (v.getId()) {
                case R.id.btnConfirm:
                    if(validateInformation()) {

                        String dep = editTextDepart.getText().toString();
                        String arr = editTextArrive.getText().toString();
                        int amount = Integer.valueOf(editTextTickets.getText().toString());

                        Dialog alert = displayFlights(dep, arr, amount);
                        alert.show();

                    }

                    break;

                case R.id.btnCancel:
                    startActivity(new Intent(ReserveActivity.this, MainActivity.class));
                    break;
            }
        }
    };


    public boolean validateInformation() {

        if(emptyFields()) {
            toastMaker("All fields must be filled.");
            return false;
        }

        int tickets = Integer.valueOf(editTextTickets.getText().toString());
        if(tickets < 1 || tickets > 7) {
            toastMaker("Invalid ticket quantity chosen.");
            return false;
        }

        return true;
    }

    public boolean emptyFields() {
        String dep = editTextDepart.getText().toString();
        String arrival = editTextArrive.getText().toString();
        String quantity = editTextTickets.getText().toString();

        return (dep.isEmpty() || arrival.isEmpty() || quantity.isEmpty());
    }

    public void toastMaker(String message) {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }

    public void makeReservation(Reservation newReservation) {
        reservationDB.addReservation(newReservation);
    }

    public Reservation getReservationFromDisplay(int seats, double price, String name) {


        String dep = flight.getDeparture();
        String arrive = flight.getArrival();
        String number = flight.getFlightNumber();

        Reservation dynamicReservation = new Reservation();

        dynamicReservation.setDeparture(dep);
        dynamicReservation.setArrival(arrive);
        dynamicReservation.setUsername(name);
        dynamicReservation.setTickets(seats);
        dynamicReservation.setPrice(price);
        dynamicReservation.setFlightnumber(number);
        dynamicReservation.setReservationNumber(reservationNum);

        return dynamicReservation;
    }

    public boolean validateLogin(String name, String pass) {
        return userDB.checkLogin(name, pass);
    }


    public Logs createLogItem(boolean successfulLogin) {
        Logs temp = new Logs();

        String logMessage = "";

        if(successfulLogin) {
            logMessage += "Reservation\n" +
                    "Flight Number " + flight.getFlightNumber() +
                    "\nDeparture: " + flight.getDeparture() + ", " + flight.getTime() +
                    "\nArrival: " + flight.getArrival() +
                    "\nNumber of tickets: " + reservation.getTickets() +
                    "\nReservation Number: " + reservation.getReservationNumber();
        } else {
            logMessage += "Login Failed";
        }

        temp.setUsername(USERNAME);
        temp.setMessage(logMessage);

        return temp;
    }



    public Dialog displayFlights(String from, String to, final int seats) {
        final AlertDialog.Builder alertBuilderFlights = new AlertDialog.Builder(ReserveActivity.this, R.style.MyDialogTheme);

        final List<Flight> flights = flightDB.getAvailable(from, to, seats);


        alertBuilderFlights.setTitle("CLICK TO SEE DETAILS").setCancelable(false);

        alertBuilderFlights.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        if(flights.size() > 0) {

            final String[] availableFlights = new String[flights.size()];

            for(int i = 0; i < flights.size(); i++) {
                availableFlights[i] = flights.get(i).getFlightNumber();
            }

            alertBuilderFlights.setSingleChoiceItems(availableFlights, -1, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int index) {

                    flight = flights.get(index);
                    displayFlightInfo(flights.get(index), seats).show();

                }
            });
        } else {
            alertBuilderFlights.setMessage("Sadly there are no flights available.");
        }

        return alertBuilderFlights.create();
    }


    public Dialog displayFlightInfo(final Flight tempFlight, final int quantity) {
        final AlertDialog.Builder alert = new AlertDialog.Builder(ReserveActivity.this, R.style.MyDialogTheme);

        final double reservationPrice = (tempFlight.getPrice() * quantity);

        alert.setTitle(tempFlight.getFlightNumber());

        alert.setMessage(
                        "Departure: " + tempFlight.getDeparture() + "\n" +
                        "Arrival: " + tempFlight.getArrival() + "\n" +
                        "Departure Time: " + tempFlight.getTime() + "\n" +
                        "Ticket Quantity: " + tempFlight.getTickets() + "\n" +
                        "Price pr: $" + tempFlight.getPrice() + "\n"
        );

        alert.setPositiveButton("Reserve", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //Intent makeReservation = new Intent(ReserveActivity.this, MainActivity.class);
                loginDialog(quantity, reservationPrice).show();

            }
        });

        alert.setNegativeButton("Back", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });


        return alert.create();
    }


    public Dialog loginDialog(final int quantity, final double price){
        final AlertDialog.Builder alert = new AlertDialog.Builder(ReserveActivity.this, R.style.MyDialogTheme);

        LayoutInflater li = LayoutInflater.from(getApplicationContext());
        View dialog_signin = li.inflate(R.layout.dialog_signin, null);

        alert.setView(dialog_signin);

        alert.setTitle("Log In To Confirm Reservation").setCancelable(false);

        final EditText usernameRaw = (EditText) dialog_signin.findViewById(R.id.username);
        final EditText passwordRaw = (EditText) dialog_signin.findViewById(R.id.password);

        alert.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                String username = usernameRaw.getText().toString();
                String password = passwordRaw.getText().toString();

                if (validateLogin(username, password)) {

                    USERNAME = username;
                    SEATS = quantity;
                    CASH = price;

                    confirmation().show();
                } else {
                    toastMaker("Login Failed");
                    log = createLogItem(false);
                    logDB.addLog(log);
                }
            }
        }).setNegativeButton("Exit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                toastMaker("Canceled reservation...");
            }
        });

        return alert.create();

    }


    public Dialog confirmation() {
        final AlertDialog.Builder alert = new AlertDialog.Builder(ReserveActivity.this, R.style.MyDialogTheme);

        alert.setTitle("Confirmation");
        alert.setCancelable(false);

        alert.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                reservation = getReservationFromDisplay(SEATS, CASH, USERNAME);
                reservationDB.addReservation(reservation);

                flight.setTickets(flight.getTickets() - SEATS);
                flightDB.updateTickets(flight);

                log = createLogItem(true);
                logDB.addLog(log);

                startActivity(new Intent(ReserveActivity.this, MainActivity.class));
            }
        });

        alert.setMessage(
                "Departure: " + flight.getDeparture() + "\n" +
                        "Username: " + USERNAME + "\n" +
                        "Arrival: " + flight.getArrival() + "\n" +
                        "Departure Time: " + flight.getTime() + "\n" +
                        "Ticket Quantity: " + SEATS + "\n" +
                        "Total Price: $" + CASH + "\n" +
                        "Reservation Number: " + reservationNum
        );

        alert.setNegativeButton("Abandon", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                cancelReservation().show();
            }
        });

        return alert.create();
    }


    public Dialog cancelReservation() {
        AlertDialog.Builder alert = new AlertDialog.Builder(ReserveActivity.this, R.style.MyDialogTheme);

        alert.setTitle("You are about to cancel");
        alert.setCancelable(false);

        alert.setMessage("Do you want to cancel the reservation you have started?");

        alert.setNegativeButton("Exit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(ReserveActivity.this, MainActivity.class));
            }
        });

        alert.setPositiveButton("Go Back", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                confirmation().show();
            }
        });


        return alert.create();
    }



}
