/**
 * TITLE: LogDB.java
 * ABSTRACT: This is the file for indirectly manipulating the log table in the database.
 * AUTHOR: Ralf Leistad
 * DATE: 12/14/2018
 */

package com.example.ralfleistad.airline_ticket_reservation;

import android.content.Context;

import com.example.ralfleistad.airline_ticket_reservation.Databse.DBHelper;

import java.util.List;

public class LogDB {

    private static LogDB sLogDB;
    private Context mContext;
    private DBHelper mDBHelper;


    public static LogDB get(Context context) {
        if(sLogDB == null){
            sLogDB = new LogDB(context);
        }
        return sLogDB;
    }

    private LogDB(Context context) {
        mContext = context.getApplicationContext();
        mDBHelper = new DBHelper(mContext);
    }

    public long addLog(Logs logs) {
        return mDBHelper.addLog(logs);
    }

    public List<Logs> getLogList() {
        return mDBHelper.getLogsList();
    }


}