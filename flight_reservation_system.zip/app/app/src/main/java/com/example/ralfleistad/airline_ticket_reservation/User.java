/**
 * TITLE: User.java
 * ABSTRACT: This is the definition for a creating a user-object.
 * AUTHOR: Ralf Leistad
 * DATE: 12/14/2018
 */

package com.example.ralfleistad.airline_ticket_reservation;

import java.util.UUID;

public class User {

    private UUID userId;
    private String username;
    private String password;
    private int sqlUserId;


    public User() {
        userId = UUID.randomUUID();
    }

    public User(UUID id) {
        userId = id;
    }

    public User(String name, String pass) {
        userId = UUID.randomUUID();
        username = name;
        password = pass;
    }

    // GETTERS AND SETTERS
    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getSqlUserId() {
        return sqlUserId;
    }

    public void setSqlUserId(int sqlUserId) {
        this.sqlUserId = sqlUserId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append(this.getUsername());

        return sb.toString();
    }
}
