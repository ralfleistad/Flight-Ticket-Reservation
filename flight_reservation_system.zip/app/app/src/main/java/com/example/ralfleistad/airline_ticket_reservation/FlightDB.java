/**
 * TITLE: FlightDB.java
 * ABSTRACT: This file indirectly manipulates the flight table in the database
 * AUTHOR: Ralf Leistad
 * DATE: 12/14/2018
 */

package com.example.ralfleistad.airline_ticket_reservation;

import android.content.Context;

import com.example.ralfleistad.airline_ticket_reservation.Databse.DBHelper;

import java.util.List;

public class FlightDB {

    private static FlightDB sFlightDB;
    private Context mContext;
    private DBHelper mDBHelper;


    public static FlightDB get(Context context) {
        if(sFlightDB == null){
            sFlightDB = new FlightDB(context);
        }
        return sFlightDB;
    }

    private FlightDB(Context context) {
        mContext = context.getApplicationContext();
        mDBHelper = new DBHelper(mContext);
    }

    public long addFlight(Flight flight) {
        return mDBHelper.addFlight(flight);
    }

    public List<Flight> getAllFlights() {
        return mDBHelper.getFlightList();
    }

    public List<Flight> getAvailable(String depart, String arr, int amount) {
        return mDBHelper.getAllAvailable(depart, arr, amount);
    }

    public void updateTickets(Flight flight) {
        mDBHelper.addFlight(flight);
    }

    public Flight getFlightFromNumber(String number) {
        return mDBHelper.getFlightFromFlightnumber(number);
    }

}