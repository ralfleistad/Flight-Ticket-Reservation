/**
 * TITLE: AddFlightActivity.java
 * ABSTRACT: This is the activity that displays the system logs and lets the system operator add a new flight.
 * AUTHOR: Ralf Leistad
 * DATE: 12/14/2018
 */

package com.example.ralfleistad.airline_ticket_reservation;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.ralfleistad.airline_ticket_reservation.Databse.DBHelper;

import java.util.Collections;
import java.util.List;

public class AddFlightActivity extends AppCompatActivity {

    Button btnConfirm;
    Button btnCancel;

    EditText editTextFlightNum;
    EditText editTextDeparture;
    EditText editTextArrival;
    EditText editTextTime;
    EditText editTextCapacity;
    EditText editTextPrice;

    Logs log;
    LogDB logDB;

    Flight flight;
    FlightDB flightDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_flight);

        btnConfirm = findViewById(R.id.btnConfirm);
        btnCancel = findViewById(R.id.btnCancel);
        editTextFlightNum = findViewById(R.id.editTextFlightNum);
        editTextDeparture = findViewById(R.id.editTextDeparture);
        editTextArrival = findViewById(R.id.editTextArrival);
        editTextTime = findViewById(R.id.editTextTime);
        editTextCapacity = findViewById(R.id.editTextCapacity);
        editTextPrice = findViewById(R.id.editTextPrice);

        btnConfirm.setOnClickListener(buttonListener);
        btnCancel.setOnClickListener(buttonListener);

        logDB = LogDB.get(this.getApplicationContext());
        flightDB = FlightDB.get(this.getApplicationContext());

        Dialog alertLog = displayLog();
        alertLog.show();
    }


    private View.OnClickListener buttonListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            switch (v.getId()) {
                case R.id.btnConfirm:

                    if(validateFlightData()) {
                        flight = getFLightFromDisplay();

                        Dialog confirm = confirmNewFlight(flight);
                        confirm.show();
                    }
                    break;

                case R.id.btnCancel:
                    startActivity(new Intent(AddFlightActivity.this, MainActivity.class));
                    break;
            }
        }
    };


    public Flight getFLightFromDisplay() {
        Flight tempFlight = new Flight();

        String number = editTextFlightNum.getText().toString();
        String dep = editTextDeparture.getText().toString();
        String arrive = editTextArrival.getText().toString();
        String time = editTextTime.getText().toString();
        int capacity = Integer.valueOf(editTextCapacity.getText().toString());
        double cost = Double.valueOf(editTextPrice.getText().toString());

        tempFlight.setFlightNumber(number);
        tempFlight.setDeparture(dep);
        tempFlight.setArrival(arrive);
        tempFlight.setTime(time);
        tempFlight.setTickets(capacity);
        tempFlight.setPrice(cost);

        return tempFlight;
    }


    public Logs getLogItem() {
        Logs tempLog = new Logs();

        String message = "New Flight";

        tempLog.setMessage(message);
        tempLog.setUsername("admin2");

        return tempLog;
    }


    public boolean validateFlightData() {

        List<Flight> flights = flightDB.getAllFlights();

        String number = editTextFlightNum.getText().toString();
        int capacity = Integer.valueOf(editTextCapacity.getText().toString());
        double cost = Double.valueOf(editTextPrice.getText().toString());

        for(Flight flight : flights) {
            if(flight.getFlightNumber().equals(number)) {
                toastMaker("The chosen Flight Number already exists");
                return false;
            }
        }


        if(capacity < 0 || cost < 0) {
            toastMaker("Price and Tickets cannot be less than 0.");
            return false;
        }

        if(emptyFields()) {
            toastMaker("No fields may remain empty.");
            return false;
        }

        return true;
    }


    public boolean emptyFields() {
        String number = editTextFlightNum.getText().toString();
        String dep = editTextDeparture.getText().toString();
        String arrive = editTextArrival.getText().toString();
        String time = editTextTime.getText().toString();
        String cost = editTextPrice.getText().toString();
        String seats = editTextCapacity.getText().toString();

        if(number.isEmpty()) {
            return true;
        } else if(dep.isEmpty()) {
            return true;
        } else if(arrive.isEmpty()) {
            return true;
        } else if(time.isEmpty()) {
            return true;
        } else if(cost.isEmpty()) {
            return true;
        } else if(seats.isEmpty()) {
            return true;
        }

        return false;
    }


    public void toastMaker(String message) {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }


    public Dialog confirmNewFlight(final Flight newFlight) {
        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(AddFlightActivity.this, R.style.MyDialogTheme);

        alertBuilder.setTitle("ADD NEW FLIGHT")
                .setCancelable(false)
                .setMessage("You are about to add this flight:\n" +
                            "Flight Number: " + flight.getFlightNumber() + "\n" +
                            "Departure: " + flight.getDeparture() + "\n" +
                            "Arrival: " + flight.getArrival() + "\n" +
                            "Departure Time: " + flight.getTime() + "\n" +
                            "Ticket Quantity: " + flight.getTickets() + "\n" +
                            "Price: $" + flight.getPrice() + "\n")
                .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        flightDB.addFlight(newFlight);
                        logDB.addLog(getLogItem());
                        finish();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        startActivity(new Intent(AddFlightActivity.this, MainActivity.class));
                    }
                });

        return alertBuilder.create();
    }


    public Dialog displayLog() {
        final AlertDialog.Builder alertBuilder = new AlertDialog.Builder(AddFlightActivity.this, R.style.MyDialogTheme);

        List<Logs> logs = logDB.getLogList();

        Collections.reverse(logs);


        alertBuilder.setTitle("SYSTEM LOGS")
                .setCancelable(false);

        alertBuilder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        if(logs != null) {
            final ArrayAdapter<Logs> arrayAdapter = new ArrayAdapter<Logs>(AddFlightActivity.this, android.R.layout.select_dialog_item);

            for (Logs log : logs) {
                arrayAdapter.add(log);
            }

            alertBuilder.setAdapter(arrayAdapter, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //dialog.dismiss();
                }
            });
        } else {
            alertBuilder.setMessage("There are no logs...");
        }

        Dialog dialog = alertBuilder.create();
        return dialog;
    }
}
