/**
 * TITLE: Flight.java
 * ABSTRACT: This is the definition of how to create a flight-object.
 * AUTHOR: Ralf Leistad
 * DATE: 12/14/2018
 */

package com.example.ralfleistad.airline_ticket_reservation;

import java.util.UUID;

public class Flight {

    private UUID flightId;
    private String flightNumber;
    private String departure;
    private String arrival;
    private String time;
    private int tickets;
    private double price;

    private int sqlFlightId;

    public Flight() {
        flightId = UUID.randomUUID();
    }

    public Flight(UUID id) {
        flightId = id;
    }

    public Flight(String number, String dep, String arrive, String depTime, int capacity, double cost) {
        flightId = UUID.randomUUID();
        flightNumber = number;
        departure = dep;
        arrival = arrive;
        time = depTime;
        tickets = capacity;
        price = cost;
    }

    public UUID getFlightId() {
        return flightId;
    }

    public void setFlightId(UUID flightId) {
        this.flightId = flightId;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getDeparture() {
        return departure;
    }

    public void setDeparture(String departure) {
        this.departure = departure;
    }

    public String getArrival() {
        return arrival;
    }

    public void setArrival(String arrival) {
        this.arrival = arrival;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getTickets() {
        return tickets;
    }

    public void setTickets(int tickets) {
        this.tickets = tickets;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getSqlFlightId() {
        return sqlFlightId;
    }

    public void setSqlFlightId(int sqlFlightId) {
        this.sqlFlightId = sqlFlightId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append(this.getFlightNumber()).append("\n");

        return sb.toString();
    }
}
