/**
 * TITLE: Schemas.java
 * ABSTRACT: This is the definition for all the tables of the database.
 * AUTHOR: Ralf Leistad
 * DATE: 12/14/2018
 */

package com.example.ralfleistad.airline_ticket_reservation.Databse;

public class Schemas {

    // TABLE FOR USERS
    public static final class UsersTable {
        public static final String NAME = "USERS";

        public static final class Cols{
            public static final String UUID     = "uuid";
            public static final String USERNAME = "username";
            public static final String PASSWORD   = "password";
        }
    }


    // TABLE FOR FLIGHTS
    public static final class FlightsTable {
        public static final String NAME = "FLIGHTS";

        public static final class Cols {
            public static final String UUID = "uuid";
            public static final String DEPARTURE = "departure";
            public static final String ARRIVAL = "arrival";
            public static final String TICKETS = "tickets";
            public static final String FLIGHTNUMBER = "flightnumber";
            public static final String PRICE = "price";
            public static final String TIME = "time";
        }
    }


    // TABLE FOR LOGS
    public static final class LogsTable {
        public static final String NAME = "LOGS";

        public static final class Cols {
            public static final String UUID = "uuid";
            public static final String DATE = "date";
            public static final String MESSAGE = "message";
            public static final String USERNAME = "username";
        }
    }


    // TABLE FOR RESERVATIONS
    public static final class ReservationsTable {
        public static final String NAME = "RESERVATIONS";

        public static final class Cols {
            public static final String UUID = "uuid";
            public static final String DEPARTURE = "departure";
            public static final String ARRIVAL = "arrival";
            public static final String TICKETS = "tickets";
            public static final String PRICE = "price";
            public static final String USERNAME = "username";
            public static final String FLIGHTNUMBER = "flightnumber";
            public static final String RESERVATIONNUMBER = "reservationnumber";
        }
    }

}
