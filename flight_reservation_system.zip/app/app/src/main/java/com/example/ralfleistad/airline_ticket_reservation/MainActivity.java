/**
 * TITLE: MainActivity.java
 * ABSTRACT: This is the main menu activity that lets the user move around the application.
 *           Also, this is where many of the other activities will return after being done with.
 * AUTHOR: Ralf Leistad
 * DATE: 12/14/2018
 */

package com.example.ralfleistad.airline_ticket_reservation;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    SharedPreferences prefs = null;

    private static final String TAG = "AIRLINE-DB";

    Button btnRegister;
    Button btnReserve;
    Button btnCancel;
    Button btnManage;

    UserDB userDB;

    FlightDB flightDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnReserve = (Button) findViewById(R.id.btnReserve);
        btnCancel = (Button) findViewById(R.id.btnCancel);
        btnManage = (Button) findViewById(R.id.btnManage);

        btnRegister.setOnClickListener(buttonListener);
        btnReserve.setOnClickListener(buttonListener);
        btnCancel.setOnClickListener(buttonListener);
        btnManage.setOnClickListener(buttonListener);

        userDB = UserDB.get(this.getApplicationContext());
        flightDB = FlightDB.get(this.getApplicationContext());

        prefs = getSharedPreferences("com.example.ralfleistad.airline_ticket_reservation", MODE_PRIVATE);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if(prefs.getBoolean("firstrun", true)) {

            Toast.makeText(getApplicationContext(), "DEFAULT DATA ADDED", Toast.LENGTH_SHORT).show();
            insertDefaultFlights();
            insertDefaultUsers();

            prefs.edit().putBoolean("firstrun", false).commit();
        }
    }

    private View.OnClickListener buttonListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            Intent registerIntent = new Intent(MainActivity.this, RegisterActivity.class);
            Intent reserveIntent = new Intent(MainActivity.this, ReserveActivity.class);
            Intent cancelIntent = new Intent(MainActivity.this, CancelActivity.class);
            Intent manageIntent = new Intent(MainActivity.this, ManageActivity.class);

            switch (v.getId()) {
                case R.id.btnRegister:
                    startActivity(registerIntent);
                    break;

                case R.id.btnReserve:
                    startActivity(reserveIntent);
                    break;

                case R.id.btnCancel:
                    startActivity(cancelIntent);
                    break;

                case R.id.btnManage:
                    startActivity(manageIntent);
                    break;
            }
        }
    };


    private void insertDefaultUsers() {
        User alice = new User("alice5", "csumb100");
        User brian = new User("brian77", "123ABC");
        User chris = new User("chris21", "CHRIS21");
        User admin = new User("admin2", "admin2");

        Log.d(TAG, "insert default users");

        userDB.addUser(alice);
        userDB.addUser(brian);
        userDB.addUser(chris);
        userDB.addUser(admin);
    }

    private void insertDefaultFlights() {

        Flight otter101 = new Flight("Otter101", "Monterey", "Los Angeles", "10:00 (AM)", 10, 150.0);
        Flight otter102 = new Flight("Otter102", "Los Angeles", "Monterey", "1:00 (PM)", 10, 150.0);
        Flight otter201 = new Flight("Otter201", "Monterey", "Seattle", "11:00 (AM)", 5, 200.5);
        Flight otter205 = new Flight("Otter205", "Monterey", "Seattle", "3:00 (PM)", 15, 150.0);
        Flight otter202 = new Flight("Otter202", "Seattle", "Monterey", "2:00 (PM)", 5, 200.5);

        Log.d(TAG, "insert default flights");

        flightDB.addFlight(otter101);
        flightDB.addFlight(otter102);
        flightDB.addFlight(otter201);
        flightDB.addFlight(otter205);
        flightDB.addFlight(otter202);

    }
}
