/**
 * TITLE: CancelActivity.java
 * ABSTRACT: This is the activity where the user may cancel their reservation.
 * AUTHOR: Ralf Leistad
 * DATE: 12/14/2018
 */

package com.example.ralfleistad.airline_ticket_reservation;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.ralfleistad.airline_ticket_reservation.Databse.Schemas;

import java.util.List;

public class CancelActivity extends AppCompatActivity {

    Button btnConfirm;
    Button btnCancel;
    EditText editTextUsername;
    EditText editTextPassword;

    User user;
    UserDB userDB;

    Reservation reservation;
    ReservationDB reservationDB;

    Flight flight;
    FlightDB flightDB;

    Logs log;
    LogDB logDB;

    String USERNAME;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancel);

        btnConfirm = findViewById(R.id.btnConfirm);
        btnCancel = findViewById(R.id.btnCancel);
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);

        btnConfirm.setOnClickListener(buttonListener);
        btnCancel.setOnClickListener(buttonListener);

        userDB = UserDB.get(this.getApplicationContext());
        reservationDB = ReservationDB.get(this.getApplicationContext());
        flightDB = FlightDB.get(this.getApplicationContext());
        logDB = LogDB.get(this.getApplicationContext());
    }

    private View.OnClickListener buttonListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            switch (v.getId()) {
                case R.id.btnConfirm:

                    String username = editTextUsername.getText().toString();
                    String password = editTextPassword.getText().toString();

                    if(validateLogin(username, password)) {
                        USERNAME = username;
                        displayReservations(username).show();
                    } else {
                        log = createLogItem(false);
                        logDB.addLog(log);
                    }

                    break;

                case R.id.btnCancel:
                    startActivity(new Intent(CancelActivity.this, MainActivity.class));
                    break;
            }
        }
    };


    public boolean validateLogin(String user, String pass) {
        return userDB.checkLogin(user, pass);
    }


    public Logs createLogItem(boolean successfulLogin) {
        Logs temp = new Logs();

        String logMessage = "";

        if(successfulLogin) {
            logMessage += "Cancellation\n" +
                    "Flight Number " + flight.getFlightNumber() +
                    "\nDeparture: " + flight.getDeparture() + ", " + flight.getTime() +
                    "\nArrival: " + flight.getArrival() +
                    "\nNumber of tickets: " + reservation.getTickets() +
                    "\nReservation Number: " + reservation.getReservationNumber();
        } else {
            logMessage += "Failed Login";
        }


        temp.setUsername(USERNAME);
        temp.setMessage(logMessage);

        return temp;
    }


    public Dialog displayReservations(String name) {
        final AlertDialog.Builder alertBuilder = new AlertDialog.Builder(CancelActivity.this, R.style.MyDialogTheme);

        final List<Reservation> reservations = reservationDB.getUsersReservations(name);

        alertBuilder.setTitle("YOUR RESERVATIONS").setCancelable(false);

        alertBuilder.setNegativeButton("Main Menu", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(CancelActivity.this, MainActivity.class));
            }
        });

        if(reservations != null && reservations.size() > 0) {
            final String[] myReservations = new String[reservations.size()];

            for (int i = 0; i < reservations.size(); i++) {
                myReservations[i] = "Reservation Number: " + String.valueOf(reservations.get(i).getReservationNumber());
            }

            alertBuilder.setSingleChoiceItems(myReservations, -1, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int index) {

                    reservation = reservations.get(index);
                    flight = flightDB.getFlightFromNumber(reservation.getFlightnumber());

                    displayInformation().show();

                }
            });
        } else {
            alertBuilder.setMessage("You have no reservations.");
        }

        return alertBuilder.create();
    }


    public Dialog displayInformation() {
        final AlertDialog.Builder alert = new AlertDialog.Builder(CancelActivity.this, R.style.MyDialogTheme);

        alert.setTitle("Do you want to cancel this flight?").setCancelable(false);

        alert.setMessage(
                        "Flight Number: " + flight.getFlightNumber() + "\n" +
                        "Departure: " + flight.getDeparture() + "\n" +
                        "Arrival: " + flight.getArrival() + "\n" +
                        "Departure Time: " + flight.getTime() + "\n" +
                        "Reservation Number: " + reservation.getReservationNumber() + "\n"
        );

        alert.setPositiveButton("Cancel Reservation", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                confirmation().show();
            }
        });

        alert.setNegativeButton("Back", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });


        return alert.create();
    }


    public Dialog confirmation() {
        final AlertDialog.Builder alert = new AlertDialog.Builder(CancelActivity.this, R.style.MyDialogTheme);

        alert.setTitle("Are you sure you want to cancel?");
        alert.setCancelable(false);

        alert.setMessage("This is the last warning you get before your cancellation is complete.");

        alert.setPositiveButton("Cancel Reservation", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                flight.setTickets(flight.getTickets() + reservation.getTickets());
                flightDB.updateTickets(flight);

                reservationDB.removeReservation(reservation.getReservationId());

                log = createLogItem(true);
                logDB.addLog(log);

                startActivity(new Intent(CancelActivity.this, MainActivity.class));

            }
        });

        alert.setNegativeButton("Keep Reservation", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(CancelActivity.this, MainActivity.class));
            }
        });

        return alert.create();
    }



}
